package com.example.service;

import org.apache.log4j.Logger;

import com.example.model.*;
import com.example.repository.*;

public class FinTxrService implements TxrService{

	private static final Logger LOGGER = Logger.getLogger("App");
	private AccountRepository accountRepository;

	
	public FinTxrService(AccountRepository accountRepository) {
		super();
		this.accountRepository = accountRepository;
	}

	
	@Override
	public boolean transfer(double amount, String fromAccNum, String toAccNum) {
		Account fromAcc = accountRepository.load(fromAccNum);
		Account toAcc = accountRepository.load(toAccNum);
		LOGGER.info("Transfer from "+fromAccNum+" to "+toAccNum+" done.");
		return true;
	}
	

}
