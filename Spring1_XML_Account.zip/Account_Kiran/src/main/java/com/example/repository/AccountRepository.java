package com.example.repository;

import com.example.model.Account;

public interface AccountRepository {

	Account load(String accNo);

	Account update(Account account);

}
