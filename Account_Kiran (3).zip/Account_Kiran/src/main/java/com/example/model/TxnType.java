package com.example.model;

public enum TxnType {
	
	DEBIT,CREDIT;
}
